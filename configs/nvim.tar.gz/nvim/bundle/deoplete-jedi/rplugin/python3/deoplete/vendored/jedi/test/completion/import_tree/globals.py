

def something():
    global foo
    foo = 3
