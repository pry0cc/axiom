#! ['class ObjectDoesNotExist']
from django.core.exceptions import ObjectDoesNotExist
import django

#? ['get_version']
django.get_version

from django.conf import settings

#? ['configured']
settings.configured
