defmodule Test.MixProject do
  # fake mix project file
end
